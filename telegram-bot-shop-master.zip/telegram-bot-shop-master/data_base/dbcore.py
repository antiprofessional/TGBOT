from sqlalchemy.ext.declarative import declarative_base
# инициализация декларативного стиля для БД
Base = declarative_base()
